import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'students',
  standalone: true,
  imports: [CommonModule],
  template: `
    <h2>{{ getTitle() }}</h2>
    <p>Current Date: {{ getCurrentDate() }}</p>
  `
})
export class StudentsComponent {
  title = 'Students Component';

  getTitle(): string {
    return this.title;
  }

  getCurrentDate(): string {
    return new Date().toLocaleDateString();
  }
}
